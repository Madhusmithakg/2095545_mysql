package com.mobiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMobileBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
