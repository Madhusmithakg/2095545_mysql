package com.mobiles.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="customerCart")
@Component
public class CustomerCart {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customercartid;
	private int customerId;
	public CustomerCart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerCart(int customercartid, int customerId) {
		super();
		this.customercartid = customercartid;
		this.customerId = customerId;
	}
	public int getCustomercartid() {
		return customercartid;
	}
	public void setCustomercartid(int customercartid) {
		this.customercartid = customercartid;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
    
	


}
