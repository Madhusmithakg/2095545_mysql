package com.mobiles.repo;

import com.mobiles.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface adminRepo extends JpaRepository<Admin ,Integer> {
	
	@Query("select ad from Admin ad where ad.emailId=(:emailId) and ad.password=(:password)")
	Admin findByLoginData(String emailId, String password);
	
	@Query("select ad from Admin ad where ad.password=(:password) and ad.confirmPassword=(:confirmPassword)")
	Admin findByRegData(String password, String confirmPassword);
}
