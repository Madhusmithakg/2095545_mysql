package com.mobiles.repo;

import com.mobiles.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface customerRepo extends JpaRepository<Customer, Integer> {
	
	@Query("select c from Customer c where c.emailId=(:emailId) and c.password=(:password)")
	Customer findbyCustomerLoginData(String emailId, String password);

}
