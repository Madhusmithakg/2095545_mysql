package com.mobiles.dao;

import com.mobiles.entity.CustomerCart;
import com.mobiles.repo.CustomerCartRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerCartDaoImpl implements CustomerCartDao{
	
	@Autowired
	CustomerCartRepo customerCartRepo;

	@Override
	public void addCustomerCart(CustomerCart customercart) {
		// TODO Auto-generated method stub
		customerCartRepo.save(customercart);
	}

}
