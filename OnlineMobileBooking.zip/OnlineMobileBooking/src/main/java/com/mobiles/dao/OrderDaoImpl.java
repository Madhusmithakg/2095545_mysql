package com.mobiles.dao;

import java.util.List;

import com.mobiles.entity.OrderDetail;
import com.mobiles.repo.OrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderDaoImpl implements OrderDao{
	
	@Autowired
	OrderRepo orRepo;

	@Override
	public void addOrder(OrderDetail order) {
		// TODO Auto-generated method stub
		orRepo.save(order);
	}

	@Override
	public List<OrderDetail> getAllOrder() {
		// TODO Auto-generated method stub
		List<OrderDetail> orderList = orRepo.findAll();
		return orderList;
		
	}

	@Override
	public void deleteOrder(int orderId) {
		// TODO Auto-generated method stub
		orRepo.deleteById(orderId);
	}

	@Override
	public void updateOder(OrderDetail order) {
		// TODO Auto-generated method stub
		orRepo.save(order);
	}

}
