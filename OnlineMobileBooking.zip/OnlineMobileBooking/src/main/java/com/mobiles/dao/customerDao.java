package com.mobiles.dao;

import java.util.List;

import com.mobiles.entity.Mobiles;
import com.mobiles.entity.Customer;
import org.springframework.stereotype.Service;

@Service
public interface customerDao {
	
	public void addCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer getCustomerById(int customerId);
	public Customer validateCustomer(Customer customer);
	
	

}
