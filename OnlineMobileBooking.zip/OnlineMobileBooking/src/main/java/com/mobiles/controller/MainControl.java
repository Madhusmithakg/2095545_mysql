package com.mobiles.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.mobiles.dao.AdminDao;
import  com.mobiles.dao.CartDao;
import  com.mobiles.dao.CustomerCartDao;
import  com.mobiles.dao.OrderDao;
import  com.mobiles.dao.mobilesDao;
import  com.mobiles.dao.customerDao;
import  com.mobiles.entity.Admin;
import  com.mobiles.entity.Mobiles;
import  com.mobiles.entity.Cart;
import  com.mobiles.entity.Customer;
import  com.mobiles.entity.CustomerCart;
import  com.mobiles.entity.OrderDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class MainControl {
	@Autowired
	Admin admin;
	
	@Autowired
	AdminDao adminDao;
	
	@Autowired
	customerDao customerdao;
	
	@Autowired
	Customer customer;
	
	@Autowired
	Customer customerNow;
	
	@Autowired
	OrderDetail order;
	
	@Autowired
	OrderDao orderDao;

	
	String msg;
	/*This method is going to return home page*/
	@RequestMapping("/welcome")
	public String welcome(Model model) {
		model.addAttribute("ad", admin);
		return "Home";
	}
	/*This method is going to return About Us*/
	@RequestMapping("/Aboutus")
	public String aboutUs(Model model) {
		model.addAttribute("ad", admin);
		return "AboutUs";
	}
	/*This method is going to return contact us */
	@RequestMapping("/Contactus")
	public String contactUs(Model model) {
		model.addAttribute("ad", admin);
		return "ContactUs";
	}
	
	/*This method is going to return admin login page*/
	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("ad", admin);
		return "index";
	}
	/*This method is going to return admin register page*/
	@RequestMapping("/AdminRegister")
	public String addAdmin(Model model) {
		model.addAttribute("ad", admin);
		return "AdminRegister";
	}
	/*This method is going to save the admin details and redirects the same page*/
	@RequestMapping("/submitform")
	public ModelAndView saveUser(@ModelAttribute("ad")  Admin admin, ModelAndView mv) throws IOException {
		
		
		adminDao.addAdmin(admin);
		mv.addObject("msg", "Admin Registered Successfully");
		
		mv.setViewName("AdminRegister");
		return mv;
	}
	
	
	/*This method is going to validate the admin details*/
	@RequestMapping("validate")
	public ModelAndView validateUser(@ModelAttribute("ad") Admin admin, @ModelAttribute("ad") Customer customer,
			Model mv, ModelAndView mv1,@RequestParam("emailId") String emailId,@RequestParam("password") String password,
			HttpSession session) {
		
		Admin admin1 = adminDao.validateAdmin(admin);
		if(admin1!=null) {
			session.setAttribute("emailId", emailId);
			mv1.addObject("ad", admin);
	//		mv1.addAttribute("ad", admin);
			mv1.setViewName("MobilesHome");
			return mv1;
		}else {
			System.out.println("Login Failed");
			
			mv1.addObject("msg", "Login failed");
			mv1.setViewName("index");
			return mv1;
		}
		
		
	}
	/*This method is going to logout from the application*/
	@RequestMapping("adminOut")
	public String adminOut() {
		return "adminLogout";
	}
	
	//--------MOBILES CONTROLLER--------------------------------------------------------
	
	
	@Autowired
	Mobiles mobile;
	
	@Autowired
	mobilesDao mobileDao;
	

	/*This method is going to return Add mobiles page*/
	@RequestMapping("/")
	public String addMobiles(Model model) {
		model.addAttribute("ad", mobile);
		return "AddMobiles";
		
	}
	/*This method is going to submit the Mobiles added by admin*/
	@RequestMapping("/submitmobile")
	public ModelAndView saveMobiles(@ModelAttribute("ad")  Mobiles mobile, ModelAndView mv,@RequestParam("pic1") MultipartFile file) throws IOException {
		byte[] Pic = file.getBytes();
		mobile.setPic(Pic);
		mobileDao.addMobiles(mobile);
		mv.addObject("msg", "Mobile added successfully");
		mv.setViewName("AddMobiles");
		return mv;
	}
	/*This method is going to return modules of admin*/
	@RequestMapping("/MobilesHome")
	public String mobilesHome() {
		return "MobilesHome";
	}
	/*This method is going to return mobile details page*/
	@RequestMapping("/ViewMobiles")
	public ModelAndView viewMobiles(ModelAndView mv) {
		List<Mobiles> mobileList=mobileDao.getallMobiles();
		mv.addObject("item", mobileList);
		mv.addObject("msg", msg);
		mv.setViewName("ViewMobiles");
		return mv;
	}
	/*This method is going to update the mobiles*/
	@RequestMapping("/Update/{mobileId}")
	public String updateMobiles(@PathVariable int mobileId, Model m) {
		Mobiles mobile=mobileDao.getmobileById(mobileId);
		m.addAttribute("ad", mobile);
		return "updateMobile";
	}
	/*This method is going to save the details of updated mobiles*/
	@RequestMapping("/saveUpdate")
	public String saveUpdatedMobile(@ModelAttribute("ad") Mobiles mobile, ModelAndView mv, @RequestParam("pic1") MultipartFile file) throws IOException  {
		byte[] Pic = file.getBytes();
		mobile.setPic(Pic);
		mobileDao.updateMobile(mobile);
		return "redirect:/ViewMobiles";
		
	}
	/*This method is going to delete the mobiles redirects the same page*/
	@RequestMapping("/deleteMobile/{mobileId}")
	public String deleteMobile(@PathVariable int mobileId) {
		mobileDao.deleteMobile(mobileId);
		return "redirect:/ViewMobiles";
	}
	
	//----------------Customer Controller-------------------------------------------------------
	/*This method is going to return customer registration page*/	
	@RequestMapping("/CustomerRegister")
	public String customerRegistration(Model model) {
		model.addAttribute("ad", customer);
		return "customerRegistration";
	}
	/*This method is going to save the customer details and redirects the same page*/
	@RequestMapping("/submitcustomer")
	public ModelAndView saveCustomer(@ModelAttribute("ad")  Customer customer, ModelAndView mv) throws IOException {
		customerdao.addCustomer(customer);
		mv.addObject("msg", "Customer Registered Successfully");
		mv.setViewName("customerRegistration");
		return mv;
	}
	/*This method is going to return login page of customer*/
	@RequestMapping("/Customerlogin")
	public String Login(Model model) {
		
		model.addAttribute("ad", customer);
		return "customerLogin";
	}
	/*This method is going to validate customer details*/
	@RequestMapping("/validateCustomer")
	public ModelAndView validateCustomer(@ModelAttribute("ad") Customer customer,  Model mv, ModelAndView mv1
			,@RequestParam("emailId") String emailId,@RequestParam("password") String password,
			HttpSession session) {
		 customerNow=customerdao.validateCustomer(customer);
			if(customerNow!=null){
			session.setAttribute("emailId", emailId);
			mv.addAttribute("ad", customerNow);
			
			List<Mobiles> mobileList=mobileDao.getallMobiles();
			mv1.addObject("item", mobileList);
			
			mv1.setViewName("mobileDetails");
			return mv1;
		}else {
			
			mv1.addObject("msg", "Login failed");
			mv1.setViewName("customerLogin");
			return mv1;
		}
	}
	
	/*This method is going to return mobile details*/
	@RequestMapping("/mobileDetails")
	public ModelAndView bookDetails(ModelAndView mv) {
		mv.addObject("ad", customerNow);
		List<Mobiles> mobileList=new ArrayList<Mobiles>();
		for(Mobiles mobile : mobileDao.getallMobiles()) {
			if(mobile.isAvailability() == true) {
				mobileList.add(mobile);
			}
		}
		mv.addObject("item", mobileList);
		mv.setViewName("mobileDetails");
		return mv;
	}
	/*This method is going to logout from the application*/
	@RequestMapping("customerOut")
	public String custOut() {
		return "customerLogout";
	}
	
	
//------------------Cart --------------------------------------------------------
	
	@Autowired
	Cart cart;
	
	@Autowired
	CartDao cartDao;
	/*This method gives add cart option to add the mobiles*/
	@RequestMapping("addtocart/{mobileId}/{customerId}")
	public ModelAndView addtoCart(ModelAndView mv,@PathVariable("mobileId") int mobileId,@PathVariable("customerId") int customerId) {
		
		
		Cart cart1 = new Cart(mobileId, customerId);
		cartDao.addCart(cart1);
		
		mv.addObject("ad", customerNow);
		mv.setViewName("redirect:/mobileDetails");
		System.out.println("added");
		return mv; 
		
	}
	/*This method is going to return wishlist based on customer id*/
	@RequestMapping("WishList/{customerId}")
	public ModelAndView showcart(@PathVariable("customerId") int customerId,ModelAndView mv) {
		mv.addObject("customerId", customerId);
		mv.addObject("menuItem", mobileDao.getallMobiles());
		mv.addObject("cartList", cartDao.getAllCart());
		mv.setViewName("showCart");
		return mv;
	}
	/*This method is going to delete the mobiles in customer cart*/
	@RequestMapping("delete/{id}/{customerId}")
	public ModelAndView deleteCart(@PathVariable("id") int id,@PathVariable("customerId") int cId,ModelAndView mv) {
		cartDao.deleteCart(id);
		mv.addObject("customerId", cId);
		mv.addObject("menuItem", mobileDao.getallMobiles());
		mv.addObject("msg", "Mobile deleted from cart");
		mv.addObject("cartList", cartDao.getAllCart());
		mv.setViewName("showCart");
		return mv;
	}
	
	//-------------------------------CustomerCart-----------------------------
	
	@Autowired
	CustomerCartDao cDao;
	
	@Autowired
	CustomerCart cCart;
	/*This method is going to get customer cart details based on customer id*/
	@RequestMapping("getCustomerCartById")
	public String getCart(Model model) {
		model.addAttribute("cart", cCart);
		return "getCart";
	}
	/*This method is going get customer cart details */
	@RequestMapping("getCustomer")
	public ModelAndView getCartCustomer(@ModelAttribute("cart") CustomerCart customercart,ModelAndView mv) {
		cDao.addCustomerCart(customercart);
		mv.setViewName("getCart");
		return mv;
	}
	/*This method is going to view customer cart for admin */
	@RequestMapping("CustomerCart/{customerId}")
	public ModelAndView showCustomercart(@PathVariable("customerId") int customerId,ModelAndView mv) {
		mv.addObject("customerId", customerId);
		mv.addObject("menuItem", mobileDao.getallMobiles());
		mv.addObject("cartList", cartDao.getAllCart());
		mv.setViewName("ViewCustomerCart");
		return mv;
	}
	
//--------------------------Order Controller----------------------------------------
	
	
	/*This method is going to place order in the application*/
	@RequestMapping("placeOrder/{mobileId}/{customerId}")
	public ModelAndView orderPlace(ModelAndView mv,@PathVariable("mobileId") int mobileId,@PathVariable("customerId") int customerId) {
		
		OrderDetail order1 = new OrderDetail(mobileId, customerId);
		orderDao.addOrder(order1);
		mv.addObject("customerId", customerId);//edited
		mv.addObject("cart", customerNow);
		mv.addObject("menuItem", mobileDao.getallMobiles());
		mv.addObject("cartList", orderDao.getAllOrder());
		mv.setViewName("OrderDetails");
		return mv;
	}
	
	/*This method is going to cancel order based on order id and customer id*/
	@RequestMapping("cancel/{orderId}/{customerId}")
	public ModelAndView deleteOrder(@PathVariable("orderId") int orderId, @PathVariable("customerId") int customerId, ModelAndView mv) {
		orderDao.deleteOrder(orderId);
		mv.addObject("customerId", customerId);
		mv.addObject("menuItem", mobileDao.getallMobiles());
		mv.addObject("cartList", orderDao.getAllOrder());
		mv.setViewName("OrderDetails");
		return mv;
	}
	
	
}












