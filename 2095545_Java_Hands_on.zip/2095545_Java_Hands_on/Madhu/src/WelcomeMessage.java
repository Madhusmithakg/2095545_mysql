
public class WelcomeMessage {
	void printMessage()
	{
		System.out.println("Welcome All");
	}
}
