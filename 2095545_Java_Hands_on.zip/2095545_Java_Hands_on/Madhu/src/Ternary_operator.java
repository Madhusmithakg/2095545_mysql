
public class Ternary_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=10;
		int num2;
		num2=(num1>5)?20:30;
		System.out.println("Value of num2 is: "+num2);

	}

}
