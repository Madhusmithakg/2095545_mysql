
public class Calculator_op {
	int num1,num2;
	void bitwise_and()
	{
		System.out.println("The bitwise AND of two numbers num1 and num2 is "+(num1&num2));
	}
	void bitwise_Or()
	{
		System.out.println("The bitwise OR of two numbers num1 and num2 is "+(num1|num2));
	}
	void bitwise_Xor()
	{
		System.out.println("The bitwise XOR of two numbers num1 and num2 is "+(num1^num2));
	}
	void bitwise_Not()
	{
		System.out.println("The bitwise NOT of two numbers num1 and num2 is "+(~num1));
	}

}
