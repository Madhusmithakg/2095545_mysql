
public class MainProgram_op {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator_op calop=new Calculator_op();
		calop.num1=15;
		calop.num2=5;
		calop.bitwise_and();
		calop.bitwise_Or();
		calop.bitwise_Not();
		calop.bitwise_Xor();
		

	}

}
