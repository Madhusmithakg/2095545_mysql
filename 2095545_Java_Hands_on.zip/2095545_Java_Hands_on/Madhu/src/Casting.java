
public class Casting {
	
	public static void main(String arg[])
	{
		int mySal=500;
		long sal=mySal;
		System.out.println(sal);
	}

}
