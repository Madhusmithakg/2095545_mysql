
public class MainProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NumberCheck big=new NumberCheck();
		big.displayBigNumber(11,18,7);
	}

}
