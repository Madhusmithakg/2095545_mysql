
public class Explicit_Casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double pf=12.67;
		float mypf=(float)pf;
		System.out.println(pf);
	}

}
