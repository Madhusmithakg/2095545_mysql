
public class TestProgram {
	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			int count=5;
			WelcomeMessage msg=new WelcomeMessage();
			for(int i=1;i<=count;i++)
			{
				msg.printMessage();
			
			}
			
				
					
		}

	}


