
public class Calculator {
	int num1,num2;
	void addition()
	{
		System.out.println("The sum of two numbers num1 and num2 is "+(num1+num2));
	}
	void subtraction()
	{
		System.out.println("The subtracted result of two numbers num1 and num2 is "+ (num1-num2));
	}
	void printsmaller()
	{
		int num3=(num1<num2)?num1:num2;
		System.out.println("The smallest of two numbers num1 and num2 is "+num3);
	}
	
}
