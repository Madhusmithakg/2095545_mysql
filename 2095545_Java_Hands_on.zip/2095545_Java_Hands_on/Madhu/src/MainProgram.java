
public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator cal=new Calculator();
		{
			cal.num1=12;
			cal.num2=8;
			cal.addition();
			cal.subtraction();
			cal.printsmaller();
		}

	}

}
