-- Problem  1:
use training_1;
select * from trainer_info where trainer_email is null;

-- Problem  2:

select trainer_id, trainer_name, trainer_track, trainer_location from trainer_info where Trainer_Expeiriance>4;

-- Problem  3: 
select * from module_info where Module_Duration>200;

-- Problem  4:
select trainer_id, trainer_name from trainer_info 
where trainer_qualification != 'Bachelor of Technology';

-- Problem  5:

select * from module_info where Module_Duration >= 200 and Module_Duration <= 300;

-- Problem  6:

select trainer_id , trainer_name from trainer_info where trainer_name like 'M%';

-- Problem  7:

select trainer_id, trainer_name from trainer_info where substring_index(trainer_name," ",1) like "%o%";

-- Problem  8:

select module_name from module_info where Module_Name is not null;