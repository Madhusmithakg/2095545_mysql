package com.shopping;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.Arrays;

import org.json.JSONException;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.shoppingcart.ShoppingCart460Application;
import com.shoppingcart.model.Brand;
import com.shoppingcart.model.Product;
import com.shoppingcart.service.ProductService;





@SuppressWarnings("deprecation")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ShoppingCart460Application.class,
webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProductServiceTest {

	@LocalServerPort
	private int port;
	
	@Autowired
	private ProductService productservice;

	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();
	
	@Before
	public void before() {
		//headers.add("Authorization", createHttpAuthenticationHeaderValue(
		//		"md", "secret"));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		
	}
	
	
	
	
	@Test 
	public void testUpdateProductMethod() {
		Product product=productservice.getProductById(100).get();
		product.setProductName("Elite");
		Product updatedproduct=productservice.updateProduct(product);
		assertThat(updatedproduct.getProductName()).isEqualTo("Elite");
	}
	
	@Test
	public void testDeleteProductMethod() {
		Product product = new Product(5,"Bike",BigDecimal.valueOf(85999.0),
				new Brand(4, "Hero", true,7));
		productservice.addProduct(product);
		String result = productservice.deleteProduct(5);
		assertEquals("Product Removerd Succesfully", result);
				
	}
	
	
	
	
	/*
	
	private String createHttpAuthenticationHeaderValue(String userId,
			String password) {

		String auth = userId + ":" + password;

		
		byte[] encodedAuth = Base64.encode(auth.getBytes(Charset
				.forName("US-ASCII")));

		String headerValue = "Basic " + new String(encodedAuth);

		return headerValue;
	}*/

}
