package com.shoppingcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingCart460Application {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCart460Application.class, args);
	}

}
