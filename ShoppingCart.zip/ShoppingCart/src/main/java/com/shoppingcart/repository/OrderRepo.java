package com.shoppingcart.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.shoppingcart.model.Order;



public interface OrderRepo extends
JpaRepository<Order, Integer> {
	List<Order> findByOrderPlacedDate(@Param("orderPlacedDate") Date orderPlacedDate);
	List<Order> findByOrderDispatchedDate(@Param("orderDispatchedDate") Date orderDispatchedDate);
	List<Order> findByOrderDeliveredDate(@Param("orderDeliveredDate") Date orderDeliveredDate);
	List<Order> findByOrderStatus(@Param("orderStatus") String orderStatus);
	//List<Order> findByCustomerId(@Param("customerId") int customerId);
	//List<Order> findByProductId(@Param("productId") int productId);
	List<Order> findByPaymentSource(@Param("paymentSource") String paymentSource);
	
	List<Order> findByPaymentStatus(@Param("paymentStatus") boolean paymentStatus);

}
