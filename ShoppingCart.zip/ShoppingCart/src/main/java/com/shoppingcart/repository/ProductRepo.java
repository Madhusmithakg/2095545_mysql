package com.shoppingcart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.shoppingcart.model.Product;



public interface ProductRepo extends JpaRepository<Product, Integer>  {

	
List<Product> findByProductName(@Param("productName") String productName);
List<Product> findByBrand(@Param("brandName") String brandName);
}
