package com.shoppingcart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.shoppingcart.model.Brand;




public interface BrandRepo extends
JpaRepository<Brand, Integer> {

	List<Brand> findByBrandName(@Param("brandName") String brandName);
	List<Brand> findByQuantity(@Param("quantity") int quantity);

	
}
